<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class insert_data_model extends CI_Model{

	function __construct(){
		parent::__construct();
		$this->load->database();
	}

	public function insert_registration($data){
		$this->db->insert('user_registration', $data);
	}
}
