<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller{

	public function index(){
	   $this->load->view('home_display');	
	   /*$this->load->helper('captcha');
	   $arr_val = array(
	   	    'word'	=> 'Random word',
	   	    'img_path' => './captcha/',
		    'img_url'	=> 'http://codeigniter.localhost.com:81/captcha/',
		    'img_width'	=> '150',
		    'img_height' => 30,
		    'expiration' => 7200
	   );
	   $cap = create_captcha($arr_val);
		echo $cap['image'];*/	  
	}
	public function add(){	
		$this->load->model('insert_data_model');	
		$data = array(
			'user_name' => $this->input->post('user_name'),
			'user_email' => $this->input->post('user_email'),
			'user_password' => $this->input->post('user_password'),
			'user_age' => $this->input->post('user_age'),
			'user_bio' => $this->input->post('user_bio'),
			'user_job' => $this->input->post('user_job'),
			'user_interests' => $this->input->post('user_interest')
		);

		$this->insert_data_model->insert_registration($data);  
	}
}