<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
  <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Login Form</title>
        <link rel="stylesheet" href="../css/normalize.css">
        <link href='http://fonts.googleapis.com/css?family=Nunito:400,300' rel='stylesheet' type='text/css'>
        <link rel="stylesheet" href="../css/style.css">


    </head>
    <body>

      <form action="/home/auth" method="post">
      
        <h1>Login</h1>
        <fieldset>
          <legend><span class="number">1</span>Your login info</legend>

          <label for="mail">Email:</label>
          <input type="email" id="mail" name="user_email" value="">
          
          <label for="password">Password:</label>
          <input type="password" id="password" name="user_password" value="">
        </fieldset>
     <button type="submit">Login</button>
      </form>
      
    </body>
</html>