<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
  <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Dash Board</title>
        <link rel="stylesheet" href="css/normalize.css">
        <link href='http://fonts.googleapis.com/css?family=Nunito:400,300' rel='stylesheet' type='text/css'>
        <link rel="stylesheet" href="../css/style.css">
        <link rel="stylesheet" type="text/css" href="../css/bootstrap.css">
        <link rel="stylesheet" href="../css/font-awesome.css">
        <script src="../JS/jquery-1.11.1.min.js" type="text/javascript"></script>
        <link rel="stylesheet" type="text/css" href="../css/theme.css">
    	<link rel="stylesheet" type="text/css" href="../css/premium.css">

    <style type="text/css">
        #line-chart {
            height:300px;
            width:800px;
            margin: 0px auto;
            margin-top: 1em;
        }
        .navbar-default .navbar-brand, .navbar-default .navbar-brand:hover { 
            color: #fff;
        }
    </style>
    <script type="text/javascript">
    	//$("[rel=tooltip]").tooltip();
        $(function() {
            var match = document.cookie.match(new RegExp('color=([^;]+)'));
            if(match) var color = match[1];
            if(color) {
                $('body').removeClass(function (index, css) {
                    return (css.match (/\btheme-\S+/g) || []).join(' ')
                })
                $('body').addClass('theme-' + color);
            }

            $('[data-popover="true"]').popover({html: true});
           
            var uls = $('.sidebar-nav > ul > *').clone();
            uls.addClass('visible-xs');
            $('#main-menu').append(uls.clone());

            $('.demo-cancel-click').click(function(){return false;});

        });

    </script>
    </head>
    <body class=" theme-blue">
    	<div class="navbar navbar-default" role="navigation">
	        <div class="navbar-header">
	          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target=".navbar-collapse">
	            <span class="sr-only">Toggle navigation</span>
	            <span class="icon-bar"></span>
	            <span class="icon-bar"></span>
	            <span class="icon-bar"></span>
	          </button>
	          <a class="" href="index.html"><span class="navbar-brand"><span class="fa fa-paper-plane"></span> Vikas Site</span></a></div>

	        <div class="navbar-collapse collapse" style="height: 1px;">
	          <ul id="main-menu" class="nav navbar-nav navbar-right">
	            <li class="dropdown hidden-xs">
	                <a href="#" class="dropdown-toggle" data-toggle="dropdown">
	                    <span class="glyphicon glyphicon-user padding-right-small" style="position:relative;top: 3px;"></span> Vikas Bose
	                    <i class="fa fa-caret-down"></i>
	                </a>

	              <ul class="dropdown-menu">
	                <li><a href="./">My Account</a></li>
	                <li class="divider"></li>
	                <li class="dropdown-header">Admin Panel</li>
	                <li><a href="./">Users</a></li>
	                <li><a href="./">Security</a></li>
	                <li><a tabindex="-1" href="./">Payments</a></li>
	                <li class="divider"></li>
	                <li><a tabindex="-1" href="sign-in.html">Logout</a></li>
	              </ul>
	            </li>
	          </ul>

	        </div>
	      </div>
	    </div>
    	
	    <div class="sidebar-nav">
		    <ul>
		    <li><a href="#" data-target=".dashboard-menu" class="nav-header" data-toggle="collapse"><i class="fa fa-fw fa-dashboard"></i> Dashboard<i class="fa fa-collapse"></i></a></li>
		    <li><ul class="dashboard-menu nav nav-list collapse in">
		            <li><a href="index.html"><span class="fa fa-caret-right"></span> Main</a></li>
		            <li ><a href="users.html"><span class="fa fa-caret-right"></span> User List</a></li>
		            <li ><a href="user.html"><span class="fa fa-caret-right"></span> User Profile</a></li>
		            <li ><a href="media.html"><span class="fa fa-caret-right"></span> Media</a></li>
		            <li ><a href="calendar.html"><span class="fa fa-caret-right"></span> Calendar</a></li>
		    </ul></li>

		    <li data-popover="true" data-content="Items in this group require a <strong><a href='http://portnine.com/bootstrap-themes/aircraft' target='blank'>premium license</a><strong>." rel="popover" data-placement="right"><a href="#" data-target=".premium-menu" class="nav-header collapsed" data-toggle="collapse"><i class="fa fa-fw fa-fighter-jet"></i> Premium Features<i class="fa fa-collapse"></i></a></li>
		        <li><ul class="premium-menu nav nav-list collapse">
		                <li class="visible-xs visible-sm"><a href="#">- Premium features require a license -</a></span>
		            <li ><a href="premium-profile.html"><span class="fa fa-caret-right"></span> Enhanced Profile</a></li>
		            <li ><a href="premium-blog.html"><span class="fa fa-caret-right"></span> Blog</a></li>
		            <li ><a href="premium-blog-item.html"><span class="fa fa-caret-right"></span> Blog Page</a></li>
		            <li ><a href="premium-pricing-tables.html"><span class="fa fa-caret-right"></span> Pricing Tables</a></li>
		            <li ><a href="premium-upgrade-account.html"><span class="fa fa-caret-right"></span> Upgrade Account</a></li>
		            <li ><a href="premium-widgets.html"><span class="fa fa-caret-right"></span> Widgets</a></li>
		            <li ><a href="premium-timeline.html"><span class="fa fa-caret-right"></span> Activity Timeline</a></li>
		            <li ><a href="premium-users.html"><span class="fa fa-caret-right"></span> Enhanced Users List</a></li>
		            <li ><a href="premium-media.html"><span class="fa fa-caret-right"></span> Enhanced Media</a></li>
		            <li ><a href="premium-invoice.html"><span class="fa fa-caret-right"></span> Invoice</a></li>
		            <li ><a href="premium-build.html"><span class="fa fa-caret-right"></span> Advanced Tools</a></li>
		            <li ><a href="premium-colors.html"><span class="fa fa-caret-right"></span> Additional Color Themes</a></li>
		    </ul></li>

		        <li><a href="#" data-target=".accounts-menu" class="nav-header collapsed" data-toggle="collapse"><i class="fa fa-fw fa-briefcase"></i> Account <span class="label label-info">+3</span></a></li>
		        <li><ul class="accounts-menu nav nav-list collapse">
		            <li ><a href="sign-in.html"><span class="fa fa-caret-right"></span> Sign In</a></li>
		            <li ><a href="sign-up.html"><span class="fa fa-caret-right"></span> Sign Up</a></li>
		            <li ><a href="reset-password.html"><span class="fa fa-caret-right"></span> Reset Password</a></li>
		    </ul></li>

		        <li><a href="#" data-target=".legal-menu" class="nav-header collapsed" data-toggle="collapse"><i class="fa fa-fw fa-legal"></i> Legal<i class="fa fa-collapse"></i></a></li>
		        <li><ul class="legal-menu nav nav-list collapse">
		            <li ><a href="privacy-policy.html"><span class="fa fa-caret-right"></span> Privacy Policy</a></li>
		            <li ><a href="terms-and-conditions.html"><span class="fa fa-caret-right"></span> Terms and Conditions</a></li>
		    </ul></li>

		        <li><a href="help.html" class="nav-header"><i class="fa fa-fw fa-question-circle"></i> Help</a></li>
		            <li><a href="faq.html" class="nav-header"><i class="fa fa-fw fa-comment"></i> Faq</a></li>
		                <li><a href="http://portnine.com/bootstrap-themes/aircraft" class="nav-header" target="blank"><i class="fa fa-fw fa-heart"></i> Get Premium</a></li>
		            </ul>
		</div>

		<div class="content">
        	<div class="header"></div>

        	<div class="main-content">
		    	<div class="col-sm-6 col-md-6">
			        <div class="panel panel-default">
			            <a href="#widget2container" class="panel-heading" data-toggle="collapse">Collapsible One </a>
			            <div id="widget2container" class="panel-body collapse in">
			                <h2>Built with Less</h2>
			                <p>The CSS is built with Less. There is a compiled version included if you prefer plain CSS.</p>
			                <p>Fava bean jícama seakale beetroot courgette shallot amaranth pea garbanzo carrot radicchio peanut leek pea sprouts arugula brussels sprout green bean. Spring onion broccoli chicory shallot winter purslane pumpkin gumbo cabbage squash beet greens lettuce celery. Gram zucchini swiss chard mustard burdock radish brussels sprout groundnut. Asparagus horseradish beet greens broccoli brussels.</p>
			                <p><a class="btn btn-primary">Learn more »</a></p>
			            </div>
			        </div>
			    </div>
			</div>
			<div class="main-content">
		    	<div class="col-sm-6 col-md-6">
			        <div class="panel panel-default">
			            <a href="#widget2container" class="panel-heading" data-toggle="collapse">Collapsible Two </a>
			            <div id="widget2container" class="panel-body collapse in">
			                <h2>Built with Less</h2>
			                <p>The CSS is built with Less. There is a compiled version included if you prefer plain CSS.</p>
			                <p>Fava bean jícama seakale beetroot courgette shallot amaranth pea garbanzo carrot radicchio peanut leek pea sprouts arugula brussels sprout green bean. Spring onion broccoli chicory shallot winter purslane pumpkin gumbo cabbage squash beet greens lettuce celery. Gram zucchini swiss chard mustard burdock radish brussels sprout groundnut. Asparagus horseradish beet greens broccoli brussels.</p>
			                <p><a class="btn btn-primary">Learn more »</a></p>
			            </div>
			        </div>
			    </div>
			</div>
			<div class="main-content">
		    	<div class="col-sm-6 col-md-6">
			        <div class="panel panel-default">
			            <a href="#widget2container" class="panel-heading" data-toggle="collapse">Collapsible Three </a>
			            <div id="widget2container" class="panel-body collapse in">
			                <h2>Built with Less</h2>
			                <p>The CSS is built with Less. There is a compiled version included if you prefer plain CSS.</p>
			                <p>Fava bean jícama seakale beetroot courgette shallot amaranth pea garbanzo carrot radicchio peanut leek pea sprouts arugula brussels sprout green bean. Spring onion broccoli chicory shallot winter purslane pumpkin gumbo cabbage squash beet greens lettuce celery. Gram zucchini swiss chard mustard burdock radish brussels sprout groundnut. Asparagus horseradish beet greens broccoli brussels.</p>
			                <p><a class="btn btn-primary">Learn more »</a></p>
			            </div>
			        </div>
			    </div>
			</div>
			<div class="main-content">
		    	<div class="col-sm-6 col-md-6">
			        <div class="panel panel-default">
			            <a href="#widget2container" class="panel-heading" data-toggle="collapse">Collapsible four </a>
			            <div id="widget2container" class="panel-body collapse in">
			                <h2>Built with Less</h2>
			                <p>The CSS is built with Less. There is a compiled version included if you prefer plain CSS.</p>
			                <p>Fava bean jícama seakale beetroot courgette shallot amaranth pea garbanzo carrot radicchio peanut leek pea sprouts arugula brussels sprout green bean. Spring onion broccoli chicory shallot winter purslane pumpkin gumbo cabbage squash beet greens lettuce celery. Gram zucchini swiss chard mustard burdock radish brussels sprout groundnut. Asparagus horseradish beet greens broccoli brussels.</p>
			                <p><a class="btn btn-primary">Learn more »</a></p>
			            </div>
			        </div>
			    </div>
			</div>
	</div>
    </body>
</html>